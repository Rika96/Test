

class Login {
   private static Login myLogin;
   private Login() {
   }
   public static Login getInstance() {
       if (myLogin == null) {
           myLogin = new Login();
       }
       return myLogin;
   }
   boolean validateUser(String user, String password) {
      if (password.equals(user))
         return true;
      else
         return false;
  }
}

class LoginMain {
   public static void main(String args[]) {
      Login login1;
      Login login2;
      login1 = Login.getInstance();
      login2 = Login.getInstance();
      System.out.println("Validate User : " + login1.validateUser("Manju", "Manjula"));

      if (login1 == login2)
         System.out.println("login1 and login2 refer to the same object in memory");
      else
         System.out.println("They are different");


   }
}
