

abstract class MobilePhone {
   protected String Model;
   protected float Price;
   abstract public void Display();
}

class A10 extends MobilePhone {
   public void Display() {
     System.out.println("A10");
   }
}

class X25 extends MobilePhone /*
*/

class TPlus extends MobilePhone /*
*/

abstract class Televison {
   //
   abstract public void Display()
}

class Alpha40 extends Television { /*
*/
class Gamma50 // 
class Theta65 //

abstract class AbstractFactory {
   public abstract MobilePhone getMobilePhone(String model);
   public abstract Television getTelevision(String TV);
}

class MobilePhoneFactory extends AbstractFactory {
    public MobilePhone getMobilePhone(String model) {
     if (model.equals("A10"))
        return new A10();
     else if (model.equals("X25"))
        return new X25();
     else if (model.equals("TPlus"))
        return new TPlus();
     else 
        return null;
  }
  public Television getTelevision(String TV) {
      return null;
  }
}
class TelevisionFactory extends AbstractFactory {
   public MobilePhone getMobilePhone(String model) {
        return null;
}
   public Television getTelevision(String TV) {
      if (TV.equals("Alpha40"))
         return new Alpha40();
      //
} 

class FactoryProducer {

   public static AbstractFactory getFactory(String name) {

          if (name.equals("MobilePhone"))
            return new MobilePhoneFactory();
          else if (name.equals("Television"))
             return new TelevisionFactory();
          else
              return null;
   }

}

class FactoryDemo {
   public static void main(String args[]) {
      String phone, tv;
      phone = "A10"; // get from keyboard
      tv = "Theta65";

      MobilePhone myphone = FactoryProducer.getFactory("MobilePhone").getMobilePhone(phone);
      Television myTv = FactoryProducer.getFactory("Television").getTelevision(tv);

  }

}
